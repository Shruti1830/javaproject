package com.infoviaan.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.infoviaan.model.StudentDAO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<body>");

		String u = req.getParameter("uname");
		String p = req.getParameter("upwd");
		int i = 0;

		StudentDAO sm = new StudentDAO();
		i = sm.adminLogin(u, p);

		if (i != 0) { // (u.equals("parro") && p.equals("kajol")) {

			HttpSession session = req.getSession();
			session.setMaxInactiveInterval(20000);
			session.setAttribute("uid", u);

			resp.sendRedirect("home.jsp");
			// out.print("<h2 style=color:blue>Login Sucessfully</h2>");
		} else {
			RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
			req.setAttribute("msg", "Invalid User Name or Password ");
			rd.forward(req, resp);
			// out.print("<h2 style=color:red>Login Failed</h2>");
		}
		// out.print("<h2>Page Login Successfully</h2>");
		out.println("</body>");
		out.println("</html>");
	}

}
