package com.infoviaan.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infoviaan.bean.StudentBean;
import com.infoviaan.model.StudentDAO;

@WebServlet("/StudentRegistrationServlet")
public class StudentRegistrationServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("sname");
		int rollno = Integer.parseInt(request.getParameter("srollno"));
		String address = request.getParameter("saddress");
		String course = request.getParameter("scourse");
		String mobile = request.getParameter("smobile");

		StudentBean sb = new StudentBean(name, rollno, address, course, mobile);

		StudentDAO model = new StudentDAO();

		int x = model.registerStudent(sb);
		PrintWriter out = response.getWriter();
		if (x != 0) {
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			request.setAttribute("msg", "Student Successfully Registered");
			rd.forward(request, response);
			// out.println("Successfully Student Data Registered");
		} else {
			System.out.println("Data not inserted");
		}
	}

}
