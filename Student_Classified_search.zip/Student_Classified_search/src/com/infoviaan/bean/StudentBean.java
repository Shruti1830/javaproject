package com.infoviaan.bean;

public class StudentBean {

	private String sname;
	private int srollno;
	private String saddress;
	private String scourse;
	private String smobile;

	public StudentBean() {

	}

	public StudentBean(String sname, int srollno, String saddress, String scourse, String smobile) {
		this.sname = sname;
		this.srollno = srollno;
		this.saddress = saddress;
		this.scourse = scourse;
		this.smobile = smobile;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getSrollno() {
		return srollno;
	}

	public void setSrollno(int srollno) {
		this.srollno = srollno;
	}

	public String getSaddress() {
		return saddress;
	}

	public String getScourse() {
		return scourse;
	}

	public void setScourse(String scourse) {
		this.scourse = scourse;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

	public String getSmobile() {
		return smobile;
	}

	public void setSmobile(String smobile) {
		this.smobile = smobile;
	}

}
